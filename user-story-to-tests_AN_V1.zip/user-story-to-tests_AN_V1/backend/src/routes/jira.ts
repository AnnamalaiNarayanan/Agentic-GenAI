import express from 'express';
import fetch from 'node-fetch';

const router = express.Router();

// GET /api/jira/:id - Proxy to Jira API to fetch issue details
router.get('/jira/:id', async (req, res) => {
  const { id } = req.params;
  const baseUrl = (process.env.JIRA_BASE_URL || 'https://testleafgenai.atlassian.net').replace(/\/$/, '');
  const username = process.env.JIRA_USERNAME || 'testleafgenai@gmail.com';
  const apiToken = process.env.JIRA_API_TOKEN || 'ATATT3xFfGF0Rk1ao-ru-v2AkjjeJFU69LQ3171_gxDwXMHvay__Vsf_RXCvMWCmoJ7iT5IaLzZOH2QW0F4Ax_FWccbB4SOVTy0nVBtjATsX2V34H1f_oPBhTPuYM3T8GMZB4_sSBR_adC9TkU-cuYJjLrV5x2QrcU9m4vBOmNeensSLMUmXwWU=8F5D27A1';

  if (!baseUrl || !username || !apiToken) {
    return res.status(500).json({ error: 'Jira credentials not set in environment.' });
  }

  // Always use the REST API endpoint
  const url = `${baseUrl}/rest/api/2/issue/${id}`;
  const auth = Buffer.from(`${username}:${apiToken}`).toString('base64');

  try {
    const response = await fetch(url, {
      headers: {
        'Authorization': `Basic ${auth}`,
        'Accept': 'application/json',
      },
    });
    if (!response.ok) {
      return res.status(response.status).json({ error: 'Failed to fetch Jira issue' });
    }
    const data: any = await response.json();
    return res.json({
      title: data?.fields?.summary ?? '',
      acceptanceCriteria: data?.fields?.description ?? '',
    });
  } catch (err) {
    return res.status(500).json({ error: 'Error fetching Jira issue' });
  }
});

export default router;
